package com.example.inventorytracker;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteConstraintException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.List;

/** Owns the persistent account and inventory tables. */
public final class InventoryDatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "inventory_tracker.db";
    private static final int DATABASE_VERSION = 1;

    private static final String TABLE_USERS = "users";
    private static final String TABLE_INVENTORY = "inventory";

    public InventoryDatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase database) {
        database.execSQL(
                "CREATE TABLE " + TABLE_USERS + " (" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        "username TEXT NOT NULL UNIQUE COLLATE NOCASE, " +
                        "password_hash TEXT NOT NULL, " +
                        "password_salt TEXT NOT NULL)"
        );
        database.execSQL(
                "CREATE TABLE " + TABLE_INVENTORY + " (" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        "name TEXT NOT NULL, " +
                        "sku TEXT NOT NULL UNIQUE COLLATE NOCASE, " +
                        "quantity INTEGER NOT NULL CHECK(quantity >= 0), " +
                        "low_stock_threshold INTEGER NOT NULL CHECK(low_stock_threshold >= 0))"
        );
    }

    @Override
    public void onUpgrade(SQLiteDatabase database, int oldVersion, int newVersion) {
        // Version 1 is the initial schema; future migrations belong here.
    }

    public boolean createUser(String username, String password) {
        String salt = PasswordHasher.newSalt();
        ContentValues values = new ContentValues();
        values.put("username", username);
        values.put("password_hash", PasswordHasher.hash(password, salt));
        values.put("password_salt", salt);
        try {
            return getWritableDatabase().insertOrThrow(TABLE_USERS, null, values) != -1;
        } catch (SQLiteConstraintException exception) {
            return false;
        }
    }

    public boolean authenticate(String username, String password) {
        try (Cursor cursor = getReadableDatabase().query(
                TABLE_USERS,
                new String[]{"password_hash", "password_salt"},
                "username = ?",
                new String[]{username},
                null,
                null,
                null,
                "1"
        )) {
            if (!cursor.moveToFirst()) {
                return false;
            }
            String expectedHash = cursor.getString(cursor.getColumnIndexOrThrow("password_hash"));
            String salt = cursor.getString(cursor.getColumnIndexOrThrow("password_salt"));
            String actualHash = PasswordHasher.hash(password, salt);
            return MessageDigest.isEqual(
                    expectedHash.getBytes(StandardCharsets.UTF_8),
                    actualHash.getBytes(StandardCharsets.UTF_8)
            );
        }
    }

    public boolean addItem(String name, String sku, int quantity, int threshold) {
        ContentValues values = new ContentValues();
        values.put("name", name);
        values.put("sku", sku);
        values.put("quantity", quantity);
        values.put("low_stock_threshold", threshold);
        try {
            return getWritableDatabase().insertOrThrow(TABLE_INVENTORY, null, values) != -1;
        } catch (SQLiteConstraintException exception) {
            return false;
        }
    }

    public void updateItemQuantity(long itemId, int quantity) {
        ContentValues values = new ContentValues();
        values.put("quantity", quantity);
        getWritableDatabase().update(
                TABLE_INVENTORY,
                values,
                "id = ?",
                new String[]{String.valueOf(itemId)}
        );
    }

    public void deleteItem(long itemId) {
        getWritableDatabase().delete(
                TABLE_INVENTORY,
                "id = ?",
                new String[]{String.valueOf(itemId)}
        );
    }

    public List<InventoryItem> getAllItems() {
        return queryItems(null, null, "name COLLATE NOCASE ASC");
    }

    public List<InventoryItem> getLowStockItems() {
        return queryItems("quantity <= low_stock_threshold", null, "quantity ASC");
    }

    private List<InventoryItem> queryItems(
            String selection,
            String[] selectionArguments,
            String orderBy
    ) {
        List<InventoryItem> items = new ArrayList<>();
        try (Cursor cursor = getReadableDatabase().query(
                TABLE_INVENTORY,
                new String[]{"id", "name", "sku", "quantity", "low_stock_threshold"},
                selection,
                selectionArguments,
                null,
                null,
                orderBy
        )) {
            while (cursor.moveToNext()) {
                items.add(new InventoryItem(
                        cursor.getLong(cursor.getColumnIndexOrThrow("id")),
                        cursor.getString(cursor.getColumnIndexOrThrow("name")),
                        cursor.getString(cursor.getColumnIndexOrThrow("sku")),
                        cursor.getInt(cursor.getColumnIndexOrThrow("quantity")),
                        cursor.getInt(cursor.getColumnIndexOrThrow("low_stock_threshold"))
                ));
            }
        }
        return items;
    }
}
