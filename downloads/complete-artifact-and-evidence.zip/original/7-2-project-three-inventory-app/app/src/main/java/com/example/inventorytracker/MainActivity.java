package com.example.inventorytracker;

import android.Manifest;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.util.List;

/** Coordinates the login, inventory, item-entry, and notification screens. */
public class MainActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_REQUEST = 1001;

    private InventoryDatabaseHelper database;
    private String pendingSmsNumber;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        database = new InventoryDatabaseHelper(this);
        showLogin(null);
    }

    @Override
    protected void onDestroy() {
        database.close();
        super.onDestroy();
    }

    public void showLogin(View view) {
        setContentView(R.layout.activity_main);
        findViewById(R.id.signInButton).setOnClickListener(ignored -> signIn());
    }

    public void showCreateAccount(View view) {
        setContentView(R.layout.activity_create_account);
        findViewById(R.id.createAccountButton).setOnClickListener(ignored -> createAccount());
    }

    public void showInventory(View view) {
        setContentView(R.layout.activity_inventory);
        renderInventory();
    }

    public void showAddItem(View view) {
        setContentView(R.layout.activity_add_item);
        findViewById(R.id.saveItemButton).setOnClickListener(ignored -> saveItem());
    }

    public void showNotifications(View view) {
        setContentView(R.layout.activity_notifications);
        updateSmsPermissionStatus();
    }

    private void signIn() {
        String username = textOf(R.id.usernameInput);
        String password = textOf(R.id.passwordInput);

        if (username.isEmpty() || password.isEmpty()) {
            toast(R.string.enter_credentials);
            return;
        }
        if (!database.authenticate(username, password)) {
            toast(R.string.invalid_credentials);
            return;
        }
        showInventory(null);
    }

    private void createAccount() {
        String username = textOf(R.id.createUsernameInput);
        String password = textOf(R.id.createPasswordInput);
        String confirmation = textOf(R.id.confirmPasswordInput);

        if (username.isEmpty() || password.isEmpty()) {
            toast(R.string.enter_credentials);
            return;
        }
        if (!password.equals(confirmation)) {
            toast(R.string.passwords_do_not_match);
            return;
        }
        if (!database.createUser(username, password)) {
            toast(R.string.username_exists);
            return;
        }

        toast(R.string.account_created);
        showInventory(null);
    }

    private void saveItem() {
        String name = textOf(R.id.itemNameInput);
        String sku = textOf(R.id.skuInput);
        Integer quantity = integerOf(R.id.quantityInput);
        Integer threshold = integerOf(R.id.thresholdInput);

        if (name.isEmpty() || sku.isEmpty() || quantity == null || threshold == null) {
            toast(R.string.complete_item_fields);
            return;
        }
        if (!database.addItem(name, sku, quantity, threshold)) {
            toast(R.string.sku_exists);
            return;
        }

        toast(R.string.item_saved);
        showInventory(null);
    }

    private void renderInventory() {
        List<InventoryItem> items = database.getAllItems();
        TextView subtitle = findViewById(R.id.inventorySubtitle);
        subtitle.setText(getResources().getQuantityString(
                R.plurals.inventory_count,
                items.size(),
                items.size(),
                countLowStock(items)
        ));

        TableLayout table = findViewById(R.id.inventoryTable);
        TextView emptyState = findViewById(R.id.emptyInventoryMessage);
        emptyState.setVisibility(items.isEmpty() ? View.VISIBLE : View.GONE);

        for (InventoryItem item : items) {
            table.addView(createInventoryRow(item));
        }
    }

    private TableRow createInventoryRow(InventoryItem item) {
        TableRow row = new TableRow(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, dp(8), 0, dp(8));

        LinearLayout nameCell = new LinearLayout(this);
        nameCell.setOrientation(LinearLayout.VERTICAL);
        TextView name = bodyText(item.getName());
        name.setTextColor(Color.rgb(23, 32, 51));
        TextView sku = bodyText(item.getSku());
        sku.setTextSize(12);
        sku.setTextColor(Color.rgb(95, 104, 120));
        nameCell.addView(name);
        nameCell.addView(sku);
        row.addView(nameCell, new TableRow.LayoutParams(dp(108), TableRow.LayoutParams.WRAP_CONTENT));

        LinearLayout quantityCell = new LinearLayout(this);
        quantityCell.setGravity(Gravity.CENTER);
        Button decrement = compactButton("−", 28);
        TextView quantity = bodyText(String.valueOf(item.getQuantity()));
        quantity.setGravity(Gravity.CENTER);
        quantity.setMinWidth(dp(32));
        quantity.setPadding(0, 0, 0, 0);
        Button increment = compactButton("+", 28);
        decrement.setOnClickListener(ignored -> updateQuantity(item, Math.max(0, item.getQuantity() - 1)));
        increment.setOnClickListener(ignored -> updateQuantity(item, item.getQuantity() + 1));
        quantityCell.addView(decrement);
        quantityCell.addView(quantity);
        quantityCell.addView(increment);
        row.addView(quantityCell, new TableRow.LayoutParams(dp(96), TableRow.LayoutParams.WRAP_CONTENT));

        TextView status = bodyText(item.isLowStock()
                ? getString(R.string.status_low)
                : getString(R.string.status_ok));
        status.setGravity(Gravity.CENTER);
        status.setTextColor(item.isLowStock()
                ? Color.rgb(163, 74, 0)
                : Color.rgb(25, 113, 60));
        row.addView(status, new TableRow.LayoutParams(dp(48), TableRow.LayoutParams.WRAP_CONTENT));

        Button delete = compactButton(getString(R.string.delete), 60);
        delete.setOnClickListener(ignored -> {
            database.deleteItem(item.getId());
            showInventory(null);
        });
        row.addView(delete, new TableRow.LayoutParams(dp(60), TableRow.LayoutParams.WRAP_CONTENT));
        return row;
    }

    private void updateQuantity(InventoryItem item, int quantity) {
        database.updateItemQuantity(item.getId(), quantity);
        showInventory(null);
    }

    public void requestSmsPermission(View view) {
        String phoneNumber = textOf(R.id.phoneNumberInput);
        if (phoneNumber.isEmpty()) {
            toast(R.string.enter_phone_number);
            return;
        }
        pendingSmsNumber = phoneNumber;

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {
            sendLowStockAlert();
            return;
        }

        ActivityCompat.requestPermissions(
                this,
                new String[]{Manifest.permission.SEND_SMS},
                SMS_PERMISSION_REQUEST
        );
    }

    @Override
    public void onRequestPermissionsResult(
            int requestCode,
            @NonNull String[] permissions,
            @NonNull int[] grantResults
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode != SMS_PERMISSION_REQUEST) {
            return;
        }

        updateSmsPermissionStatus();
        if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            sendLowStockAlert();
        } else {
            toast(R.string.sms_denied_inventory_works);
        }
    }

    @SuppressWarnings("deprecation")
    private void sendLowStockAlert() {
        List<InventoryItem> lowStockItems = database.getLowStockItems();
        if (lowStockItems.isEmpty()) {
            toast(R.string.no_low_stock_items);
            return;
        }

        InventoryItem item = lowStockItems.get(0);
        String message = getString(
                R.string.low_stock_message,
                item.getName(),
                item.getQuantity(),
                item.getLowStockThreshold()
        );
        try {
            SmsManager.getDefault().sendTextMessage(pendingSmsNumber, null, message, null, null);
            toast(R.string.sms_sent);
        } catch (RuntimeException exception) {
            toast(R.string.sms_unavailable);
        }
    }

    private void updateSmsPermissionStatus() {
        TextView status = findViewById(R.id.smsPermissionStatus);
        if (status == null) {
            return;
        }
        boolean granted = ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED;
        status.setText(granted ? R.string.sms_permission_granted : R.string.sms_permission_not_granted);
        status.setTextColor(granted ? Color.rgb(25, 113, 60) : Color.rgb(95, 104, 120));
    }

    private int countLowStock(List<InventoryItem> items) {
        int count = 0;
        for (InventoryItem item : items) {
            if (item.isLowStock()) {
                count++;
            }
        }
        return count;
    }

    private String textOf(int viewId) {
        EditText input = findViewById(viewId);
        return input.getText().toString().trim();
    }

    private Integer integerOf(int viewId) {
        try {
            int value = Integer.parseInt(textOf(viewId));
            return value < 0 ? null : value;
        } catch (NumberFormatException exception) {
            return null;
        }
    }

    private TextView bodyText(String value) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(14);
        view.setPadding(dp(4), dp(4), dp(4), dp(4));
        return view;
    }

    private Button compactButton(String label, int widthDp) {
        Button button = new Button(this);
        button.setText(label);
        button.setTextSize(11);
        button.setAllCaps(false);
        button.setWidth(dp(widthDp));
        button.setMinWidth(0);
        button.setMinimumWidth(0);
        button.setMinHeight(dp(40));
        button.setPadding(0, 0, 0, 0);
        return button;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private void toast(int messageId) {
        Toast.makeText(this, messageId, Toast.LENGTH_SHORT).show();
    }
}
