# CS-360 Project Three: Inventory Tracker

This Android Studio project is the finished version of my inventory app. It uses Java, XML layouts, and a local SQLite database. The minimum supported Android version is API 33.

## Functional flow

- A new user can create an account, and returning users can sign in with the saved credentials. Passwords are salted and hashed before they are stored.
- The inventory screen reads saved items from SQLite and presents them in a grid. A user can add an item, increase or decrease its quantity, or delete it. The data remains available after the app closes and reopens.
- Each item has a low-stock threshold. The inventory summary and status column show which items need attention.
- The notifications screen requests SMS permission only when the user tries to send an alert. If permission is denied, the inventory functions continue to work. If permission is granted, the app can send a text alert for a low-stock item.
- The screens provide a complete path through sign-in, account creation, inventory, item entry, notifications, and sign-out (OpenAI, 2026).

## Build and run verification

The project was built with the included Gradle wrapper using `clean`, `lintDebug`, and `assembleDebug`. I installed the debug build on an API 36 Android emulator and checked account creation, sign-in, item creation, quantity changes, deletion, database persistence after relaunch, navigation, both SMS permission outcomes, and a successful low-stock alert (OpenAI, 2026).

## AI use acknowledgement

I used OpenAI Codex with GPT-5.6 to help implement, test, and revise the Android app. I reviewed the source code, build results, and emulator behavior before preparing the submission (OpenAI, 2026).

## Reference

OpenAI. (2026). *Codex (GPT-5.6)* [AI coding agent]. https://openai.com/codex/
