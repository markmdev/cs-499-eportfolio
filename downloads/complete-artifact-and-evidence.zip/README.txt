Inventory Tracker database enhancement
markmdev - CS499 - October 4, 2026

original/: exact original CS360 source file bytes.
enhanced/: cumulative Android source including workflow, restock selector and database history. See enhanced/README.md for build/run instructions.
evidence/: actual emulator/test evidence. Benchmark CSV is preserved Module Four evidence for the unchanged selector.

9 unit tests, 7 database instrumentation tests, 13 UI instrumentation tests pass. Android lint: 0 errors, 23 warnings.
