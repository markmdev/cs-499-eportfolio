# Inventory Tracker — Database Enhancement

CS-499 Module Five, October 4, 2026. markmdev.

The Java Android app originated in CS-360 Project Three in August 2026. This version replaces immediate quantity buttons with a signed adjustment, reason, preview, and confirmation. Cancel makes no write. A stale quantity or missing item produces an explicit failure and requires review again. The local shared-inventory and account model remains intact.

## Build and run

Open this project in Android Studio with Android SDK 36.1 installed and JDK 21. The included Gradle wrapper uses the original project's dependencies; no new library was added. Configure the SDK location through Android Studio or `ANDROID_HOME`.

```sh
./gradlew assembleDebug testDebugUnitTest lintDebug
./gradlew connectedDebugAndroidTest
```

The second command needs an Android emulator or device, API 33 or newer. Tests create local test accounts and replace inventory fixtures. Database migration tests delete and recreate the entire local test database; run them only in a disposable test emulator. They do not send SMS. Screenshots are taken from the real emulator during tests.

Create an account or sign in, add an item, and choose **Adjust**. Enter a nonzero whole-number change such as `+5` or `-2` and a reason. Preview shows the old and proposed stock. Confirm once, or edit/cancel. Changing orientation preserves the current operation. Starting a new app process requires signing in and a new adjustment; it never replays a command.

Choose **Restock shortlist** to request the most urgent k items. Stockouts come first, then the lowest quantity/threshold ratio. SKU and ID break ties. Zero thresholds qualify only for stockouts. Enter zero for an empty list; negative, blank or out-of-range limits show a validation error. An adjustment opened from the shortlist returns to a refreshed shortlist. Changing orientation retains the requested limit.

Choose **History** below an item name to see its recorded adjustments, newest first. Each entry shows its UTC time, item snapshot, before/after stock, signed change and reason. A new or migrated item has no history until an adjustment is confirmed. History screen state survives rotation.

## Code responsibilities

- `MainActivity`: screens, input, permission handling, main-thread rendering.
- `InventoryViewModel`: retained screen/operation state and a serial background executor for account hashing and all database work. Its `Phase` transitions are EDITING → LOADING → PREVIEW → SAVING → SUCCESS or ERROR.
- `StockAdjustment`: immutable preview and validated quantity arithmetic.
- `InventoryDatabaseHelper`: SQLite schema v2, migration, expected-quantity checking and atomic quantity/history adjustment. APPLIED, STALE, and MISSING are distinct results; database exceptions reach the visible error state.
- `StockMovement`: immutable snapshot of one committed adjustment.
- `InventoryItem` and `PasswordHasher`: unchanged baseline data and hashing logic.
- `RestockSelector`: exact ratio comparison, bounded-heap selection, and a full-sort reference. Inputs are repository records with unique IDs and nonnegative integer stock values.

Schema version 2 adds `stock_movements` and the `(item_id, created_at, id)` index without rebuilding users or inventory. `onConfigure` enables foreign keys. Movement records retain SKU/name snapshots; deleting an item sets its movement references to null rather than erasing those records. The per-item screen covers existing items; retained deleted-item rows are available in SQLite, not a separate archive screen. Migration does not invent past movements.

The quantity update and movement insertion commit together. Failure of either write rolls back the transaction. CHECK constraints require integer stock within Java int bounds, a nonzero delta consistent with before/after quantities, and a nonempty reason. Values use bound parameters or ContentValues. Epoch milliseconds represent UTC; display uses UTC explicitly. The app remains local and shared: this history is not tamper-proof and does not identify individual employees.

## Verification

Nine local test methods cover adjustment input, ranking edge cases, integer bounds and randomized agreement with an independent BigInteger ordering oracle. Twenty Android instrumentation tests exercise the Activity and real SQLite database, including cancellation, signed changes, stale/missing items, a database-triggered failure, and recreation during a deliberately blocked save. The same save is confirmed twice and still applied once. Regression coverage includes account creation/login, item creation/deletion, and the notification screen without SMS delivery. Failed login, duplicate account, and duplicate SKU checks preserve form entries. A blocked write can finish after the Activity closes without delivering callbacks to its disposed ViewModel. Tests wait for operation completion before checking an inventory mutation.

The shortlist emulator test checks shortlist size, rotation, relative ranking, refresh after a confirmed adjustment, and clearing stale results when an invalid limit prevents reload. The `evidence/` folder in the submission archive contains runtime screenshots and test reports. Android lint completed with warnings; those are not represented as a warning-free result. A fresh Activity test verifies that an unconfirmed preview is not reused.

Seven database tests verify populated v1 migration and authentication preservation, persisted before/after values, rollback after a rejected movement insert, stale/missing commands, deletion snapshots, SQL constraints (including fractional values), and history filtering/tie ordering. EXPLAIN QUERY PLAN is saved with the index and after removing it in a disposable test database. A new UI test checks empty history, a confirmed movement, navigation and rotation. Existing cancellation and repeated-confirmation tests also check movement counts.

## Selection complexity and benchmark

After loading n items with m eligible candidates, let h = min(k,m). For k > 0, the heap uses O(h) auxiliary storage, O(n + m log(h+1)) selection time, and O(h log(h+1)) output sorting. The full-sort reference uses O(m) storage and O(n + m log(m+1)) time. Both receive the existing O(n) repository list; the SQL name ordering, loading and UI rendering are excluded from these bounds and timings.

`benchmark/RestockBenchmark.java` generates seeded test data, checks identical outputs, performs ten warmups and twenty-one measured runs in alternating order, and reports median milliseconds. Run it from the project root:

```sh
javac -d out app/src/main/java/com/example/inventorytracker/InventoryItem.java app/src/main/java/com/example/inventorytracker/RestockSelector.java benchmark/RestockBenchmark.java
java -cp out RestockBenchmark
```
 The included Module Four CSV contains all nine measured cases from September 28, 2026; it is retained evidence for the unchanged selector. These are local JVM measurements, not Android performance claims. Small k benefits from the heap; near n the full sort was faster in this run.

## AI assistance

The original CS-360 project used OpenAI Codex with GPT-5.6, as disclosed in its preserved README. OpenAI Codex with GPT-6 Astra assisted with the cumulative enhancements, test design and execution, and documentation. Prompts requested the approved adjustment workflow, bounded-heap shortlist, and version-2 transactional movement history; original-source preservation; independent ordering checks; migration and rollback tests; and real emulator verification (OpenAI, 2026).

OpenAI. (2026). *Codex (GPT-6 Astra)* [AI coding agent]. https://openai.com/codex/
