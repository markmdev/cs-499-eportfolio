package com.example.inventorytracker;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteConstraintException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import java.util.List;
import org.junit.*;
import org.junit.runner.RunWith;
import static org.junit.Assert.*;

/** Database version 2 verification — markmdev, October 4, 2026. */
@RunWith(AndroidJUnit4.class)
public class MovementDatabaseTest {
    private Context context;
    private InventoryDatabaseHelper helper;
    @Before public void prepare() {
        context = InstrumentationRegistry.getInstrumentation().getTargetContext();
        context.deleteDatabase("inventory_tracker.db");
        helper = new InventoryDatabaseHelper(context);
    }
    @After public void close() { helper.close(); }
    private InventoryItem item() {
        assertTrue(helper.addItem("USB cable", "USB-01", 10, 3));
        return helper.getAllItems().get(0);
    }
    private long scalar(String sql) {
        try (Cursor c = helper.getReadableDatabase().rawQuery(sql, null)) { assertTrue(c.moveToFirst()); return c.getLong(0); }
    }
    private void evidence(String file, String text) {
        try (java.io.FileOutputStream out = new java.io.FileOutputStream(new java.io.File(context.getExternalFilesDir(null), file))) {
            out.write(text.getBytes(java.nio.charset.StandardCharsets.UTF_8));
        } catch (java.io.IOException e) { throw new AssertionError(e); }
    }
    @Test public void populatedVersionOneUpgradePreservesAccountsAndInventory() {
        helper.close();
        SQLiteOpenHelper legacy = new SQLiteOpenHelper(context, "inventory_tracker.db", null, 1) {
            public void onCreate(SQLiteDatabase db) {
                db.execSQL("CREATE TABLE users (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT NOT NULL UNIQUE COLLATE NOCASE, password_hash TEXT NOT NULL, password_salt TEXT NOT NULL)");
                db.execSQL("CREATE TABLE inventory (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, sku TEXT NOT NULL UNIQUE COLLATE NOCASE, quantity INTEGER NOT NULL CHECK(quantity >= 0), low_stock_threshold INTEGER NOT NULL CHECK(low_stock_threshold >= 0))");
            }
            public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) { }
        };
        SQLiteDatabase v1 = legacy.getWritableDatabase();
        String salt = PasswordHasher.newSalt();
        v1.execSQL("INSERT INTO users VALUES (?, ?, ?, ?)", new Object[]{7, "existing-user", PasswordHasher.hash("existing-password", salt), salt});
        v1.execSQL("INSERT INTO inventory VALUES (?, ?, ?, ?, ?)", new Object[]{42, "Existing cable", "OLD-42", 17, 4});
        assertEquals(1, v1.getVersion()); legacy.close();
        helper = new InventoryDatabaseHelper(context);
        assertEquals(2, helper.getWritableDatabase().getVersion());
        assertTrue(helper.authenticate("EXISTING-USER", "existing-password"));
        assertFalse(helper.authenticate("existing-user", "wrong"));
        InventoryItem preserved = helper.getItem(42);
        assertEquals("Existing cable", preserved.getName()); assertEquals("OLD-42", preserved.getSku());
        assertEquals(17, preserved.getQuantity()); assertEquals(4, preserved.getLowStockThreshold());
        assertEquals(0, scalar("SELECT count(*) FROM stock_movements"));
        assertEquals(1, scalar("PRAGMA foreign_keys"));
        helper.applyAdjustment(new StockAdjustment(preserved, -3, "Used"));
        assertEquals(14, helper.getItem(42).getQuantity()); assertEquals(1, helper.getItemHistory(42).size());
        evidence("migration-proof.txt", "Populated schema v1 -> v2\nAccount id 7 preserved; case-insensitive authentication passed; wrong password rejected.\nInventory id42 Existing cable / OLD-42 / quantity17 / threshold4 preserved.\nNo historical movement fabricated. Foreign keys enabled.\nFirst post-upgrade adjustment:17 -3 =14; exactly one movement.\n");
    }
    @Test public void successStoresExactMovementAndReopenPersistsIt() {
        InventoryItem item = item(); long before = System.currentTimeMillis();
        assertEquals(InventoryDatabaseHelper.AdjustmentResult.APPLIED, helper.applyAdjustment(new StockAdjustment(item, -3, "  Damaged stock  ")));
        assertEquals(7, helper.getItem(item.getId()).getQuantity());
        List<StockMovement> history = helper.getItemHistory(item.getId()); assertEquals(1, history.size());
        StockMovement movement = history.get(0);
        assertEquals("USB-01", movement.sku); assertEquals("USB cable", movement.name);
        assertEquals(10, movement.oldQuantity); assertEquals(-3, movement.delta); assertEquals(7, movement.newQuantity);
        assertEquals("Damaged stock", movement.reason); assertTrue(movement.createdAt >= before && movement.createdAt <= System.currentTimeMillis());
        helper.close(); helper = new InventoryDatabaseHelper(context);
        assertEquals(1, helper.getItemHistory(item.getId()).size());
        assertEquals(InventoryDatabaseHelper.AdjustmentResult.APPLIED, helper.applyAdjustment(new StockAdjustment(helper.getItem(item.getId()), 5, "Shipment received")));
        assertEquals(12, helper.getItem(item.getId()).getQuantity()); assertEquals(2, helper.getItemHistory(item.getId()).size());
    }
    @Test public void movementInsertFailureRollsBackQuantity() {
        InventoryItem item = item();
        helper.getWritableDatabase().execSQL("CREATE TRIGGER reject_movement BEFORE INSERT ON stock_movements BEGIN SELECT RAISE(ABORT, 'injected history failure'); END");
        try { helper.applyAdjustment(new StockAdjustment(item, 5, "Shipment")); fail("Expected failed history insert"); }
        catch (SQLiteConstraintException expected) { }
        assertEquals(10, helper.getItem(item.getId()).getQuantity()); assertTrue(helper.getItemHistory(item.getId()).isEmpty());
        helper.getWritableDatabase().execSQL("DROP TRIGGER reject_movement");
        helper.applyAdjustment(new StockAdjustment(item, 5, "Shipment"));
        assertEquals(15, helper.getItem(item.getId()).getQuantity()); assertEquals(1, helper.getItemHistory(item.getId()).size());
        evidence("rollback-proof.txt", "Injected BEFORE INSERT trigger rejected stock_movements write after quantity update.\nQuantity remained10; history remained empty.\nAfter trigger removal, same adjustment produced quantity15 and exactly one movement.\n");
    }
    @Test public void staleAndMissingCommandsCreateNoMovement() {
        InventoryItem item = item(); StockAdjustment command = new StockAdjustment(item, 2, "Shipment");
        helper.applyAdjustment(new StockAdjustment(item, 1, "First"));
        assertEquals(InventoryDatabaseHelper.AdjustmentResult.STALE, helper.applyAdjustment(command));
        assertEquals(11, helper.getItem(item.getId()).getQuantity()); assertEquals(1, scalar("SELECT count(*) FROM stock_movements"));
        helper.deleteItem(item.getId());
        assertEquals(InventoryDatabaseHelper.AdjustmentResult.MISSING, helper.applyAdjustment(command));
        assertEquals(1, scalar("SELECT count(*) FROM stock_movements"));
    }
    @Test public void deletionRetainsSnapshotsAndDoesNotAttachToReplacementSku() {
        InventoryItem item = item(); helper.applyAdjustment(new StockAdjustment(item, -2, "Used"));
        helper.deleteItem(item.getId());
        try (Cursor c = helper.getReadableDatabase().rawQuery("SELECT item_id,sku,name,old_quantity,delta,new_quantity,reason FROM stock_movements", null)) {
            assertTrue(c.moveToFirst()); assertTrue(c.isNull(0)); assertEquals("USB-01", c.getString(1)); assertEquals("USB cable", c.getString(2));
            assertEquals(10, c.getInt(3)); assertEquals(-2, c.getInt(4)); assertEquals(8, c.getInt(5)); assertEquals("Used", c.getString(6));
        }
        InventoryItem replacement = item(); assertNotEquals(item.getId(), replacement.getId());
        assertTrue(helper.getItemHistory(replacement.getId()).isEmpty());
        assertEquals(0, scalar("SELECT count(*) FROM pragma_foreign_key_check"));
    }
    private ContentValues validMovement(long itemId) {
        ContentValues v = new ContentValues(); v.put("item_id", itemId); v.put("sku", "USB-01"); v.put("name", "USB cable");
        v.put("old_quantity", 10); v.put("delta", -2); v.put("new_quantity", 8); v.put("reason", "Used"); v.put("created_at", 1234);
        return v;
    }
    private void reject(ContentValues v) {
        try { helper.getWritableDatabase().insertOrThrow("stock_movements", null, v); fail("Invalid movement accepted: " + v); }
        catch (SQLiteConstraintException expected) { }
    }
    @Test public void databaseConstraintsRejectInvalidRows() {
        long id = item().getId();
        ContentValues v = validMovement(id); v.put("old_quantity", -1); reject(v);
        v = validMovement(id); v.put("new_quantity", 2147483648L); reject(v);
        v = validMovement(id); v.put("delta", 0); v.put("new_quantity", 10); reject(v);
        v = validMovement(id); v.put("delta", -1); reject(v);
        v = validMovement(id); v.put("old_quantity", 10.5); v.put("new_quantity", 8.5); reject(v);
        v = validMovement(id); v.put("delta", -1.5); v.put("new_quantity", 8.5); reject(v);
        v = validMovement(id); v.put("reason", " \t\n "); reject(v);
        v = validMovement(id); v.putNull("reason"); reject(v);
        v = validMovement(id); v.put("item_id", id + 100); reject(v);
        assertEquals(0, scalar("SELECT count(*) FROM stock_movements"));
    }
    private String queryPlan(long itemId) {
        StringBuilder result = new StringBuilder();
        try (Cursor c = helper.getReadableDatabase().rawQuery("EXPLAIN QUERY PLAN SELECT * FROM stock_movements WHERE item_id = ? ORDER BY created_at DESC, id DESC", new String[]{String.valueOf(itemId)})) {
            while (c.moveToNext()) result.append(c.getString(3)).append('\n');
        }
        return result.toString();
    }
    @Test public void historyIsFilteredStableAndIndexed() {
        long id = item().getId();
        for (int i = 0; i < 3; i++) helper.getWritableDatabase().insertOrThrow("stock_movements", null, validMovement(id));
        helper.addItem("Other", "OTHER", 1, 0);
        long other = 0; for (InventoryItem candidate : helper.getAllItems()) if (candidate.getSku().equals("OTHER")) other = candidate.getId();
        helper.getWritableDatabase().insertOrThrow("stock_movements", null, validMovement(other));
        List<StockMovement> rows = helper.getItemHistory(id); assertEquals(3, rows.size());
        assertTrue(rows.get(0).id > rows.get(1).id && rows.get(1).id > rows.get(2).id);
        String indexed = queryPlan(id); assertTrue(indexed.contains("movement_item_time")); assertFalse(indexed.contains("TEMP B-TREE"));
        helper.getWritableDatabase().execSQL("DROP INDEX movement_item_time");
        String unindexed = queryPlan(id); assertTrue(unindexed.contains("SCAN")); assertTrue(unindexed.contains("TEMP B-TREE"));
        evidence("query-plan-proof.txt", "Indexed query:\n" + indexed + "\nIndex removed only in disposable test database:\n" + unindexed + "\nThree tied-timestamp rows returned in descending movement-ID order; other item excluded.\n");
    }
}
