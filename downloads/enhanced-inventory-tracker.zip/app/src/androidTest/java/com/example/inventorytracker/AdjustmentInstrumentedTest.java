package com.example.inventorytracker;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import androidx.test.core.app.ActivityScenario;
import androidx.test.platform.app.InstrumentationRegistry;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import org.junit.*;
import org.junit.runner.RunWith;
import static org.junit.Assert.*;
import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.*;
import static androidx.test.espresso.matcher.ViewMatchers.*;
import static androidx.test.espresso.assertion.ViewAssertions.matches;

@RunWith(AndroidJUnit4.class)
public class AdjustmentInstrumentedTest {
    private InventoryDatabaseHelper db;
    private InventoryItem item;
    private ActivityScenario<MainActivity> activity;
    private final String name = "Module Three Cable";
    @Before public void prepare() {
        Context context = InstrumentationRegistry.getInstrumentation().getTargetContext();
        db = new InventoryDatabaseHelper(context);
        db.createUser("capstone-test", "local-test-password");
        db.getWritableDatabase().delete("inventory", "sku = ?", new String[]{"CS499-M3-TEST"});
        db.addItem(name, "CS499-M3-TEST", 10, 3);
        for (InventoryItem candidate : db.getAllItems()) if (candidate.getSku().equals("CS499-M3-TEST")) item = candidate;
        activity = ActivityScenario.launch(MainActivity.class);
        onView(withId(R.id.usernameInput)).perform(replaceText("capstone-test"));
        onView(withId(R.id.passwordInput)).perform(replaceText("local-test-password"), closeSoftKeyboard());
        onView(withId(R.id.signInButton)).perform(click());
        awaitText("Inventory");
    }
    @After public void close() {
        if (activity != null) activity.close();
        db.getWritableDatabase().execSQL("DROP TRIGGER IF EXISTS reject_test_adjustment");
        db.close();
    }
    private void awaitText(String text) {
        if (text.equals("Inventory")) awaitIdle();
        long deadline = System.currentTimeMillis() + 10000;
        while (System.currentTimeMillis() < deadline) {
            try { onView(withText(text)).check(matches(isDisplayed())); return; }
            catch (AssertionError | RuntimeException notReady) {
                android.os.SystemClock.sleep(40);
            }
        }
        onView(withText(text)).check(matches(isDisplayed()));
    }
    private void awaitIdle() {
        java.util.concurrent.atomic.AtomicBoolean idle = new java.util.concurrent.atomic.AtomicBoolean();
        long deadline = System.currentTimeMillis() + 10000;
        do {
            activity.onActivity(a -> idle.set(!new androidx.lifecycle.ViewModelProvider(a).get(InventoryViewModel.class).busy));
            if (idle.get()) return;
            android.os.SystemClock.sleep(40);
        } while (System.currentTimeMillis() < deadline);
        fail("Operation did not finish within 10 seconds");
    }
    private void capture(String name) {
        android.os.SystemClock.sleep(500);
        android.graphics.Bitmap screenshot = InstrumentationRegistry.getInstrumentation().getUiAutomation().takeScreenshot();
        Context context = InstrumentationRegistry.getInstrumentation().getTargetContext();
        try (java.io.FileOutputStream out = new java.io.FileOutputStream(new java.io.File(context.getExternalFilesDir(null), name + ".png"))) {
            screenshot.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, out);
        } catch (java.io.IOException error) { throw new AssertionError(error); }
        finally { screenshot.recycle(); }
    }
    private void begin(String delta, String reason) {
        onView(withContentDescription("Adjust " + name)).perform(scrollTo(), click());
        onView(withId(R.id.adjustmentDelta)).perform(replaceText(delta));
        onView(withId(R.id.adjustmentReason)).perform(replaceText(reason), closeSoftKeyboard());
    }
    private void preview(String delta, String reason, int quantity) {
        begin(delta, reason);
        onView(withText("Preview adjustment")).perform(scrollTo(), click());
        awaitText("New quantity: " + quantity);
    }
    @Test public void historyDisplaysCommittedChangesAndSurvivesRotation() {
        onView(withContentDescription("History for " + name)).perform(scrollTo(), click());
        awaitText("No recorded adjustments for this item.");
        onView(withText("Back to inventory")).perform(scrollTo(), click()); awaitText("Inventory");
        preview("-3", "Damaged stock", 7);
        onView(withText("Confirm adjustment")).perform(scrollTo(), click()); awaitText("Stock updated to 7.");
        onView(withText("Back to inventory")).perform(scrollTo(), click()); awaitText("Inventory");
        onView(withContentDescription("History for " + name)).perform(scrollTo(), click());
        awaitText("10 → 7 (-3)"); awaitText("Reason: Damaged stock");
        activity.recreate(); awaitText("10 → 7 (-3)");
        capture("stock-history");
        assertEquals(1, db.getItemHistory(item.getId()).size());
        onView(withText("Back to inventory")).perform(scrollTo(), click()); awaitText("Inventory");
    }

    @Test public void accountItemAndNotificationRegression() {
        onView(withText("Sign out")).perform(scrollTo(), click());
        onView(withText("Create account")).perform(click());
        onView(withId(R.id.createUsernameInput)).perform(replaceText("test-" + System.currentTimeMillis()));
        onView(withId(R.id.createPasswordInput)).perform(replaceText("local-test-password"));
        onView(withId(R.id.confirmPasswordInput)).perform(replaceText("local-test-password"), closeSoftKeyboard());
        onView(withId(R.id.createAccountButton)).perform(click()); awaitText("Inventory");
        onView(withText("Add item")).perform(click());
        onView(withId(R.id.itemNameInput)).perform(replaceText("Regression item"));
        onView(withId(R.id.skuInput)).perform(replaceText("REG-" + System.currentTimeMillis()));
        onView(withId(R.id.quantityInput)).perform(replaceText("4"));
        onView(withId(R.id.thresholdInput)).perform(replaceText("2"), closeSoftKeyboard());
        onView(withId(R.id.saveItemButton)).perform(scrollTo(), click()); awaitText("Inventory");
        onView(withText("Notifications")).perform(click());
        onView(withId(R.id.smsPermissionStatus)).check(matches(isDisplayed()));
        capture("notifications-permission-state");
        androidx.test.espresso.Espresso.pressBack(); awaitText("Inventory");
        onView(org.hamcrest.Matchers.allOf(withText("Delete"), withParent(hasDescendant(withText("Regression item"))))).perform(scrollTo(), click());
        awaitText("Inventory");
        for (InventoryItem row : db.getAllItems()) assertNotEquals("Regression item", row.getName());
    }
    @Test public void recoverableErrorsKeepFormValues() {
        onView(withText("Sign out")).perform(scrollTo(), click());
        onView(withId(R.id.usernameInput)).perform(replaceText("capstone-test"));
        onView(withId(R.id.passwordInput)).perform(replaceText("wrong-password"), closeSoftKeyboard());
        onView(withId(R.id.signInButton)).perform(click()); awaitIdle();
        onView(withId(R.id.usernameInput)).check(matches(withText("capstone-test")));
        onView(withId(R.id.passwordInput)).check(matches(withText("wrong-password")));
        onView(withText("Create account")).perform(click());
        onView(withId(R.id.createUsernameInput)).perform(replaceText("capstone-test"));
        onView(withId(R.id.createPasswordInput)).perform(replaceText("local-test-password"));
        onView(withId(R.id.confirmPasswordInput)).perform(replaceText("local-test-password"), closeSoftKeyboard());
        onView(withId(R.id.createAccountButton)).perform(click()); awaitIdle();
        onView(withId(R.id.createUsernameInput)).check(matches(withText("capstone-test")));
        onView(withId(R.id.createPasswordInput)).check(matches(withText("local-test-password")));
        onView(withId(R.id.confirmPasswordInput)).check(matches(withText("local-test-password")));
        androidx.test.espresso.Espresso.pressBack();
        onView(withId(R.id.usernameInput)).perform(replaceText("capstone-test"));
        onView(withId(R.id.passwordInput)).perform(replaceText("local-test-password"), closeSoftKeyboard());
        onView(withId(R.id.signInButton)).perform(click()); awaitText("Inventory");
        onView(withText("Add item")).perform(click());
        onView(withId(R.id.itemNameInput)).perform(replaceText("Keep this item"));
        onView(withId(R.id.skuInput)).perform(replaceText("CS499-M3-TEST"));
        onView(withId(R.id.quantityInput)).perform(replaceText("7"));
        onView(withId(R.id.thresholdInput)).perform(replaceText("2"), closeSoftKeyboard());
        onView(withId(R.id.saveItemButton)).perform(scrollTo(), click()); awaitIdle();
        onView(withId(R.id.itemNameInput)).check(matches(withText("Keep this item")));
        onView(withId(R.id.skuInput)).check(matches(withText("CS499-M3-TEST")));
        onView(withId(R.id.quantityInput)).check(matches(withText("7")));
        onView(withId(R.id.thresholdInput)).check(matches(withText("2")));
        onView(withId(R.id.saveItemButton)).check(matches(isEnabled()));
    }
    @Test public void closingDuringSaveDoesNotRestartDisposedWorker() throws Exception {
        String sku = "CLOSE-" + System.currentTimeMillis();
        CountDownLatch locked = new CountDownLatch(1), release = new CountDownLatch(1);
        Thread lock = new Thread(() -> {
            SQLiteDatabase connection = SQLiteDatabase.openDatabase(db.getReadableDatabase().getPath(), null, SQLiteDatabase.OPEN_READWRITE);
            connection.beginTransaction(); locked.countDown();
            try { release.await(10, TimeUnit.SECONDS); }
            catch (InterruptedException e) { Thread.currentThread().interrupt(); }
            finally { connection.endTransaction(); connection.close(); }
        });
        lock.start(); assertTrue(locked.await(5, TimeUnit.SECONDS));
        try {
            activity.onActivity(a -> new androidx.lifecycle.ViewModelProvider(a).get(InventoryViewModel.class).add("Closing operation", sku, 1, 0));
            activity.close();
        } finally { release.countDown(); lock.join(5000); }
        long deadline = System.currentTimeMillis() + 10000;
        InventoryItem added = null;
        while (added == null && System.currentTimeMillis() < deadline) {
            for (InventoryItem row : db.getAllItems()) if (row.getSku().equals(sku)) added = row;
            if (added == null) android.os.SystemClock.sleep(40);
        }
        assertNotNull("The already-running save should finish", added);
        db.deleteItem(added.getId());
        InstrumentationRegistry.getInstrumentation().waitForIdleSync();
        activity = ActivityScenario.launch(MainActivity.class);
        onView(withId(R.id.signInButton)).check(matches(isDisplayed()));
    }
    @Test public void positiveNegativeAndCancel() {
        preview("+5", "Shipment received", 15);
        capture("adjustment-preview");
        onView(withText("Cancel")).perform(scrollTo(), click());
        awaitText("Inventory"); assertEquals(10, db.getItem(item.getId()).getQuantity());
        assertTrue(db.getItemHistory(item.getId()).isEmpty());
        preview("+5", "Shipment received", 15);
        onView(withText("Confirm adjustment")).perform(scrollTo(), click());
        awaitText("Stock updated to 15.");
        capture("adjustment-success");
        onView(withText("Back to inventory")).perform(scrollTo(), click()); awaitText("Inventory");
        preview("-15", "Stock used", 0);
        onView(withText("Confirm adjustment")).perform(scrollTo(), click());
        awaitText("Stock updated to 0."); assertEquals(0, db.getItem(item.getId()).getQuantity());
    }
    @Test public void invalidInputNeverWrites() {
        begin("0", "Count correction");
        onView(withText("Preview adjustment")).perform(scrollTo(), click());
        awaitText("Enter a nonzero whole-number change.");
        onView(withId(R.id.adjustmentDelta)).perform(replaceText("-11"), closeSoftKeyboard());
        onView(withText("Preview adjustment")).perform(scrollTo(), click());
        awaitText("Resulting stock must be between 0 and 2,147,483,647.");
        onView(withId(R.id.adjustmentDelta)).perform(replaceText("2"));
        onView(withId(R.id.adjustmentReason)).perform(replaceText(""), closeSoftKeyboard());
        onView(withText("Preview adjustment")).perform(scrollTo(), click());
        awaitText("Enter a reason for this adjustment.");
        assertEquals(10, db.getItem(item.getId()).getQuantity());
        assertTrue(db.getItemHistory(item.getId()).isEmpty());
    }
    @Test public void stalePreviewRequiresReview() {
        preview("+5", "Shipment received", 15);
        assertEquals(InventoryDatabaseHelper.AdjustmentResult.APPLIED, db.applyAdjustment(new StockAdjustment(item, 1, "Other adjustment")));
        onView(withText("Confirm adjustment")).perform(scrollTo(), click());
        awaitText("Stock changed since your preview. Preview again before confirming.");
        capture("adjustment-stale");
        assertEquals(11, db.getItem(item.getId()).getQuantity());
        onView(withText("Preview adjustment")).perform(scrollTo(), click()); awaitText("New quantity: 16");
        onView(withText("Confirm adjustment")).perform(scrollTo(), click()); awaitText("Stock updated to 16.");
    }
    @Test public void deletedItemIsExplicit() {
        preview("-2", "Used", 8); db.deleteItem(item.getId());
        onView(withText("Confirm adjustment")).perform(scrollTo(), click());
        awaitText("This item was deleted. Return to inventory.");
        assertNull(db.getItem(item.getId()));
    }
    @Test public void databaseFailureCanRecover() {
        preview("+5", "Shipment received", 15);
        db.getWritableDatabase().execSQL("CREATE TRIGGER reject_test_adjustment BEFORE UPDATE ON inventory WHEN NEW.sku = 'CS499-M3-TEST' BEGIN SELECT RAISE(ABORT, 'test write failure'); END");
        onView(withText("Confirm adjustment")).perform(scrollTo(), click());
        awaitText("Could not save the adjustment. Preview current stock before trying again.");
        capture("adjustment-error");
        assertEquals(10, db.getItem(item.getId()).getQuantity());
        db.getWritableDatabase().execSQL("DROP TRIGGER reject_test_adjustment");
        onView(withText("Preview adjustment")).perform(scrollTo(), click()); awaitText("New quantity: 15");
        onView(withText("Confirm adjustment")).perform(scrollTo(), click()); awaitText("Stock updated to 15.");
    }
    @Test public void rotationKeepsEditingAndPreview() {
        begin("+5", "Shipment received"); activity.recreate();
        onView(withId(R.id.adjustmentDelta)).check(matches(withText("+5")));
        onView(withId(R.id.adjustmentReason)).check(matches(withText("Shipment received")));
        onView(withText("Preview adjustment")).perform(scrollTo(), click()); awaitText("New quantity: 15");
        activity.recreate(); awaitText("New quantity: 15");
        onView(withText("Confirm adjustment")).perform(scrollTo(), click()); awaitText("Stock updated to 15.");
        activity.recreate(); awaitText("Stock updated to 15.");
        assertEquals(15, db.getItem(item.getId()).getQuantity());
        assertEquals(1, db.getItemHistory(item.getId()).size());
    }
    @Test public void savingSurvivesRotationAndRepeatedConfirmation() throws Exception {
        preview("+5", "Shipment received", 15);
        CountDownLatch locked = new CountDownLatch(1), release = new CountDownLatch(1);
        Thread lock = new Thread(() -> {
            SQLiteDatabase connection = SQLiteDatabase.openDatabase(db.getReadableDatabase().getPath(), null, SQLiteDatabase.OPEN_READWRITE);
            connection.beginTransaction(); locked.countDown();
            try { release.await(10, TimeUnit.SECONDS); }
            catch (InterruptedException e) { Thread.currentThread().interrupt(); }
            finally { connection.endTransaction(); connection.close(); }
        });
        lock.start(); assertTrue(locked.await(5, TimeUnit.SECONDS));
        try {
            activity.onActivity(a -> {
                InventoryViewModel model = new androidx.lifecycle.ViewModelProvider(a).get(InventoryViewModel.class);
                model.confirm(); model.confirm();
            });
            awaitText("Saving adjustment…"); activity.recreate(); awaitText("Saving adjustment…"); capture("adjustment-saving-after-rotation");
        } finally { release.countDown(); lock.join(5000); }
        awaitText("Stock updated to 15."); assertEquals(15, db.getItem(item.getId()).getQuantity());
        assertEquals(1, db.getItemHistory(item.getId()).size());
    }
    @Test public void newActivityDoesNotReplayUnconfirmedPreview() {
        preview("+5", "Shipment received", 15);
        activity.close(); activity = ActivityScenario.launch(MainActivity.class);
        onView(withId(R.id.signInButton)).check(matches(isDisplayed()));
        assertEquals(10, db.getItem(item.getId()).getQuantity());
    }

    @Test public void restockLimitRotationAndRefreshAfterAdjustment() {
        db.getWritableDatabase().delete("inventory", null, null);
        db.addItem("Stockout cable", "A-OUT", 0, 0);
        db.addItem("USB adapters", "B-ADAPT", 3, 30);
        db.addItem("HDMI leads", "C-HDMI", 2, 3);
        db.addItem("Chargers", "D-CHARGE", 8, 5);
        onView(withId(R.id.restockButton)).perform(scrollTo(), click()); awaitIdle();
        onView(withText("1. Stockout cable · A-OUT")).check(matches(isDisplayed()));
        onView(withId(R.id.restockLimit)).perform(replaceText("2"), closeSoftKeyboard());
        onView(withText("Update shortlist")).perform(scrollTo(), click()); awaitIdle();
        activity.onActivity(a -> assertEquals(2, new androidx.lifecycle.ViewModelProvider(a).get(InventoryViewModel.class).restockItems.size()));
        activity.recreate(); awaitIdle();
        onView(withId(R.id.restockLimit)).check(matches(withText("2")));
        capture("restock-ranked-shortlist");
        onView(withText("Adjust Stockout cable")).perform(scrollTo(), click());
        onView(withId(R.id.adjustmentDelta)).perform(replaceText("5"));
        onView(withId(R.id.adjustmentReason)).perform(replaceText("Shipment received"), closeSoftKeyboard());
        onView(withText("Preview adjustment")).perform(scrollTo(), click()); awaitIdle();
        onView(withText("Confirm adjustment")).perform(scrollTo(), click()); awaitIdle();
        onView(withText("Back to shortlist")).perform(scrollTo(), click()); awaitIdle();
        onView(withText("1. USB adapters · B-ADAPT")).perform(scrollTo()).check(matches(isDisplayed()));
        onView(withText("2. HDMI leads · C-HDMI")).perform(scrollTo()).check(matches(isDisplayed()));
        capture("restock-after-adjustment");
        onView(withId(R.id.restockLimit)).perform(scrollTo(), replaceText(""), closeSoftKeyboard());
        onView(withText("Adjust USB adapters")).perform(scrollTo(), click());
        onView(withId(R.id.adjustmentDelta)).perform(replaceText("2"));
        onView(withId(R.id.adjustmentReason)).perform(replaceText("Stock count"), closeSoftKeyboard());
        onView(withText("Preview adjustment")).perform(scrollTo(), click()); awaitIdle();
        onView(withText("Confirm adjustment")).perform(scrollTo(), click()); awaitIdle();
        onView(withText("Back to shortlist")).perform(scrollTo(), click()); awaitIdle();
        onView(withText("Enter zero or a positive whole number.")).check(matches(isDisplayed()));
        activity.onActivity(a -> assertTrue(new androidx.lifecycle.ViewModelProvider(a).get(InventoryViewModel.class).restockItems.isEmpty()));
        onView(withId(R.id.restockLimit)).perform(replaceText("0"), closeSoftKeyboard());
        onView(withText("Update shortlist")).perform(scrollTo(), click()); awaitIdle();
        onView(withText("No items in this shortlist.")).check(matches(isDisplayed()));
        onView(withId(R.id.restockLimit)).perform(replaceText("10"), closeSoftKeyboard());
        onView(withText("Update shortlist")).perform(scrollTo(), click()); awaitIdle();
        onView(withText("Back to inventory")).perform(scrollTo(), click()); awaitIdle();
        onView(withText("Chargers")).perform(scrollTo()).check(matches(isDisplayed()));
    }
}
