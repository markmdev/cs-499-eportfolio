package com.example.inventorytracker;

import org.junit.Test;
import static org.junit.Assert.*;
import java.util.*;
import java.math.BigInteger;

public class RestockSelectorTest {
    private InventoryItem item(long id, String sku, int q, int t) {
        return new InventoryItem(id, sku, sku, q, t);
    }
    private List<Long> ids(List<InventoryItem> items) {
        List<Long> result = new ArrayList<>();
        for (InventoryItem i : items) result.add(i.getId());
        return result;
    }
    @Test public void ranksStockoutsBeforeRelativeCoverage() {
        List<InventoryItem> input = Arrays.asList(item(1,"C",2,3), item(2,"D",3,30),
                item(3,"B",0,0), item(4,"A",0,20), item(5,"E",7,2));
        assertEquals(Arrays.asList(4L,3L,2L),ids(RestockSelector.select(input,3)));
        assertEquals(Arrays.asList(4L,3L,2L,1L),ids(RestockSelector.select(input,99)));
    }
    @Test public void equalCoverageUsesSkuThenId() {
        List<InventoryItem> input=Arrays.asList(item(4,"A",2,6),item(3,"A",1,3),item(1,"B",3,9));
        assertEquals(Arrays.asList(3L,4L,1L),ids(RestockSelector.select(input,3)));
    }
    @Test public void boundarySizesDoNotMutateInput() {
        List<InventoryItem> input=Collections.unmodifiableList(Arrays.asList(item(1,"A",2,3)));
        assertTrue(RestockSelector.select(input,0).isEmpty());
        assertTrue(RestockSelector.select(Collections.emptyList(),5).isEmpty());
        assertEquals(Arrays.asList(1L),ids(RestockSelector.select(input,Integer.MAX_VALUE)));
        assertEquals(1,input.size());
    }
    @Test public void rejectsInvalidLimitsAndStock() {
        assertThrows(IllegalArgumentException.class,()->RestockSelector.select(Collections.emptyList(),-1));
        assertThrows(IllegalArgumentException.class,()->RestockSelector.select(Arrays.asList(item(1,"A",-1,2)),1));
        assertThrows(IllegalArgumentException.class,()->RestockSelector.select(Arrays.asList(item(1,"A",0,-1)),1));
    }
    @Test public void maximumIntProductsRemainExact() {
        int m=Integer.MAX_VALUE;
        List<InventoryItem> input=Arrays.asList(item(1,"A",m-1,m),item(2,"B",m-2,m-1));
        assertEquals(Arrays.asList(2L,1L),ids(RestockSelector.select(input,2)));
    }
    @Test public void agreesWithIndependentRationalOracleAcrossRandomInputs() {
        Random r=new Random(499);
        Comparator<InventoryItem> oracle=(a,b)->{
            int zero=Boolean.compare(b.getQuantity()==0,a.getQuantity()==0);
            if(zero!=0)return zero;
            if(a.getQuantity()!=0){
                int ratio=BigInteger.valueOf(a.getQuantity()).multiply(BigInteger.valueOf(b.getLowStockThreshold()))
                    .compareTo(BigInteger.valueOf(b.getQuantity()).multiply(BigInteger.valueOf(a.getLowStockThreshold())));
                if(ratio!=0)return ratio;
            }
            int sku=a.getSku().compareTo(b.getSku());
            return sku!=0?sku:Long.compare(a.getId(),b.getId());
        };
        for(int trial=0;trial<100;trial++) {
            List<InventoryItem> input=new ArrayList<>();
            for(int i=0;i<200;i++)input.add(item(i,"S"+r.nextInt(20),r.nextInt(31),r.nextInt(31)));
            List<InventoryItem> expected=new ArrayList<>();
            for(InventoryItem i:input)if(i.getQuantity()<=i.getLowStockThreshold())expected.add(i);
            expected.sort(oracle);
            Collections.shuffle(input,r);
            for(int k:new int[]{0,1,5,20,199,250}) {
                List<InventoryItem> got=RestockSelector.select(input,k);
                assertEquals(ids(expected.subList(0,Math.min(k,expected.size()))),ids(got));
                assertEquals(got.size(),new HashSet<>(ids(got)).size());
            }
        }
    }
}
