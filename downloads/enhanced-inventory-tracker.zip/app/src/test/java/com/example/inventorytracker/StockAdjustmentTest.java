package com.example.inventorytracker;

import org.junit.Test;
import static org.junit.Assert.*;

public class StockAdjustmentTest {
    private InventoryItem item(int quantity) { return new InventoryItem(1, "Cable", "C-1", quantity, 3); }
    @Test public void signedAdjustments() {
        assertEquals(15, new StockAdjustment(item(10), 5, " shipment ").quantity);
        assertEquals("shipment", new StockAdjustment(item(10), 5, " shipment ").reason);
        assertEquals(0, new StockAdjustment(item(10), -10, "used").quantity);
    }
    @Test public void integerBoundaries() {
        assertEquals(Integer.MAX_VALUE, new StockAdjustment(item(Integer.MAX_VALUE - 1), 1, "count").quantity);
        assertThrows(IllegalArgumentException.class, () -> new StockAdjustment(item(Integer.MAX_VALUE), 1, "count"));
        assertThrows(IllegalArgumentException.class, () -> new StockAdjustment(item(0), Integer.MIN_VALUE, "count"));
    }
    @Test public void invalidCommands() {
        assertThrows(IllegalArgumentException.class, () -> new StockAdjustment(item(10), 0, "count"));
        assertThrows(IllegalArgumentException.class, () -> new StockAdjustment(item(10), -11, "count"));
        assertThrows(IllegalArgumentException.class, () -> new StockAdjustment(item(10), 1, "  "));
    }
}
