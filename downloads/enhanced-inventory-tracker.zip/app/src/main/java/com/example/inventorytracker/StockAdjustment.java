package com.example.inventorytracker;

/**
 * Immutable preview: confirmation applies exactly the quantity the user reviewed.
 * CS-499 Module Three — markmdev, September 20, 2026.
 */
public final class StockAdjustment {
    public final InventoryItem item;
    public final int delta;
    public final String reason;
    public final int quantity;

    public StockAdjustment(InventoryItem item, int delta, String reason) {
        validateInput(delta, reason);
        long proposed = (long) item.getQuantity() + delta;
        if (proposed < 0 || proposed > Integer.MAX_VALUE) {
            throw new IllegalArgumentException("Resulting stock must be between 0 and 2,147,483,647.");
        }
        this.item = item;
        this.delta = delta;
        this.reason = reason.trim();
        this.quantity = (int) proposed;
    }

    public static void validateInput(int delta, String reason) {
        if (delta == 0) throw new IllegalArgumentException("Enter a nonzero whole-number change.");
        if (reason == null || reason.trim().isEmpty()) {
            throw new IllegalArgumentException("Enter a reason for this adjustment.");
        }
    }
}
