package com.example.inventorytracker;

/**
 * Snapshot of one committed stock adjustment, independent of later item deletion.
 * CS-499 Module Five — markmdev, October 4, 2026. Schema version 2.
 */
public final class StockMovement {
    public final long id;
    public final String sku, name, reason;
    public final int oldQuantity, delta, newQuantity;
    public final long createdAt;

    public StockMovement(long id, String sku, String name, int oldQuantity, int delta,
                         int newQuantity, String reason, long createdAt) {
        this.id = id; this.sku = sku; this.name = name; this.oldQuantity = oldQuantity;
        this.delta = delta; this.newQuantity = newQuantity; this.reason = reason; this.createdAt = createdAt;
    }
}
