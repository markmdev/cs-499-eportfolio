package com.example.inventorytracker;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.PriorityQueue;

/** Selects from repository records with unique IDs and nonnegative int stock values. */
public final class RestockSelector {
    private RestockSelector() { }

    public static final Comparator<InventoryItem> PRIORITY = (a, b) -> {
        int stockout = Boolean.compare(b.getQuantity() == 0, a.getQuantity() == 0);
        if (stockout != 0) return stockout;
        if (a.getQuantity() != 0) {
            long left = (long) a.getQuantity() * b.getLowStockThreshold();
            long right = (long) b.getQuantity() * a.getLowStockThreshold();
            int coverage = Long.compare(left, right);
            if (coverage != 0) return coverage;
        }
        int sku = a.getSku().compareTo(b.getSku());
        return sku != 0 ? sku : Long.compare(a.getId(), b.getId());
    };

    /** For k > 0 and h = min(k, eligible), scans n records in O(n + eligible * log(h+1))
     * time, then orders h results in O(h * log(h+1)); O(h) storage favors short lists. */
    public static List<InventoryItem> select(List<InventoryItem> items, int k) {
        if (k < 0) throw new IllegalArgumentException("Enter zero or a positive whole number.");
        if (k == 0) return new ArrayList<>();
        // Reversing the output order puts the least urgent retained item at the root.
        PriorityQueue<InventoryItem> heap = new PriorityQueue<>(PRIORITY.reversed());
        for (InventoryItem item : items) {
            if (item.getQuantity() < 0 || item.getLowStockThreshold() < 0)
                throw new IllegalArgumentException("Stock values cannot be negative.");
            if (!item.isLowStock()) continue;
            if (heap.size() < k) heap.add(item);
            else if (PRIORITY.compare(item, heap.peek()) < 0) {
                heap.remove();
                heap.add(item);
            }
        }
        List<InventoryItem> result = new ArrayList<>(heap);
        result.sort(PRIORITY);
        return result;
    }

    public static List<InventoryItem> fullSort(List<InventoryItem> items, int k) {
        if (k < 0) throw new IllegalArgumentException("Enter zero or a positive whole number.");
        List<InventoryItem> eligible = new ArrayList<>();
        if (k == 0) return eligible;
        for (InventoryItem item : items) {
            if (item.getQuantity() < 0 || item.getLowStockThreshold() < 0)
                throw new IllegalArgumentException("Stock values cannot be negative.");
            if (item.isLowStock()) eligible.add(item);
        }
        eligible.sort(PRIORITY);
        return new ArrayList<>(eligible.subList(0, Math.min(k, eligible.size())));
    }
}
