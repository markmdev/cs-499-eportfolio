package com.example.inventorytracker;

import android.app.Application;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.MutableLiveData;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.function.Consumer;

/**
 * Retains the current operation across rotation; no command is restored after process death.
 * CS-499 Module Five — markmdev, October 4, 2026. Enhancement version 3.
 */
public final class InventoryViewModel extends AndroidViewModel {
    public enum Screen { LOGIN, ACCOUNT, INVENTORY, ADD, NOTIFICATIONS, RESTOCK, HISTORY, ADJUST }
    public enum Phase { EDITING, LOADING, PREVIEW, SAVING, SUCCESS, ERROR }
    public final MutableLiveData<Integer> changes = new MutableLiveData<>(0);
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private final Handler main = new Handler(Looper.getMainLooper());
    private final InventoryDatabaseHelper repository;
    private boolean disposed;
    public Screen screen = Screen.LOGIN;
    public Phase phase = Phase.EDITING;
    public boolean busy;
    public String message = "";
    public List<InventoryItem> items = new ArrayList<>();
    public List<StockMovement> movements = new ArrayList<>();
    public String restockLimitText = "5";
    public List<InventoryItem> restockItems = new ArrayList<>();
    private Screen adjustmentReturnScreen = Screen.INVENTORY;
    public InventoryItem selected;
    public StockAdjustment preview;
    public String deltaText = "";
    public String reasonText = "";
    public String pendingSmsNumber;
    public InventoryItem smsItem;

    public InventoryViewModel(Application app) {
        super(app);
        repository = new InventoryDatabaseHelper(app);
    }

    private void changed() { changes.setValue(changes.getValue() + 1); }

    private <T> void run(Callable<T> action, Consumer<T> success, Consumer<Exception> failure) {
        if (disposed || busy) return;
        busy = true;
        changed();
        worker.execute(() -> {
            try {
                T result = action.call();
                main.post(() -> {
                    if (disposed) return;
                    busy = false; success.accept(result); changed();
                });
            } catch (Exception error) {
                Log.e("InventoryTracker", "Inventory operation failed", error);
                main.post(() -> {
                    if (disposed) return;
                    busy = false; failure.accept(error); changed();
                });
            }
        });
    }

    private void failed(Exception error) { message = "Could not complete the operation. Please try again."; }

    public void navigate(Screen destination) {
        if (busy) return;
        screen = destination;
        message = "";
        smsItem = null;
        if (destination == Screen.LOGIN) {
            selected = null; preview = null; deltaText = ""; reasonText = "";
        }
        if (destination == Screen.INVENTORY) refresh();
        else if (destination == Screen.RESTOCK) loadRestock();
        else changed();
    }

    public void refresh() {
        run(repository::getAllItems, result -> items = result, this::failed);
    }

    public void loadRestock() {
        if (busy) return;
        final int k;
        try {
            k = Integer.parseInt(restockLimitText.trim());
            if (k < 0) throw new NumberFormatException();
        } catch (NumberFormatException error) {
            restockItems = new ArrayList<>();
            message = "Enter zero or a positive whole number.";
            changed(); return;
        }
        message = "";
        run(() -> RestockSelector.select(repository.getAllItems(), k), result -> {
            restockItems = result;
            message = result.isEmpty() ? "No items in this shortlist." : "";
        }, this::failed);
    }

    public void signIn(String username, String password, boolean create) {
        if (username.isEmpty() || password.isEmpty()) { message = getApplication().getString(R.string.enter_credentials); changed(); return; }
        run(() -> create ? repository.createUser(username, password) : repository.authenticate(username, password), result -> {
            if (!result) { message = getApplication().getString(create ? R.string.username_exists : R.string.invalid_credentials); return; }
            screen = Screen.INVENTORY; message = "";
            // Schedule the read separately so account hashing and every query remain off the UI thread.
            refresh();
        }, this::failed);
    }

    public void add(String name, String sku, int quantity, int threshold) {
        run(() -> repository.addItem(name, sku, quantity, threshold), result -> {
            if (!result) { message = getApplication().getString(R.string.sku_exists); return; }
            screen = Screen.INVENTORY; message = getApplication().getString(R.string.item_saved); refresh();
        }, this::failed);
    }

    public void delete(long id) {
        run(() -> { repository.deleteItem(id); return repository.getAllItems(); }, result -> {
            items = result; message = "Item deleted.";
        }, this::failed);
    }

    public void showHistory(InventoryItem item) {
        if (busy) return;
        selected = item; screen = Screen.HISTORY; message = "";
        movements = new ArrayList<>();
        run(() -> repository.getItemHistory(item.getId()), result -> movements = result, this::failed);
    }

    public void select(InventoryItem item) {
        if (busy) return;
        adjustmentReturnScreen = screen == Screen.RESTOCK ? Screen.RESTOCK : Screen.INVENTORY;
        selected = item; preview = null; deltaText = ""; reasonText = "";
        screen = Screen.ADJUST; phase = Phase.EDITING; message = ""; changed();
    }

    public void preview() {
        if (busy) return;
        final int delta;
        try {
            delta = Integer.parseInt(deltaText.trim());
            StockAdjustment.validateInput(delta, reasonText);
        } catch (IllegalArgumentException error) {
            phase = Phase.ERROR;
            message = error instanceof NumberFormatException ? "Enter a whole-number change, such as +5 or -2." : error.getMessage();
            changed(); return;
        }
        String reason = reasonText;
        phase = Phase.LOADING; message = ""; preview = null;
        run(() -> {
            InventoryItem item = repository.getItem(selected.getId());
            return item == null ? null : new StockAdjustment(item, delta, reason);
        }, result -> {
            if (result == null) { phase = Phase.ERROR; message = "This item was deleted. Return to inventory."; }
            else { preview = result; selected = result.item; phase = Phase.PREVIEW; }
        }, error -> { phase = Phase.ERROR; message = error instanceof IllegalArgumentException ? error.getMessage() : "Could not load stock. Try Preview again."; });
    }

    public void edit() {
        if (busy) return;
        preview = null; phase = Phase.EDITING; message = ""; changed();
    }

    public void confirm() {
        if (busy || phase != Phase.PREVIEW || preview == null) return;
        StockAdjustment command = preview;
        phase = Phase.SAVING;
        run(() -> repository.applyAdjustment(command), result -> {
            if (result == InventoryDatabaseHelper.AdjustmentResult.APPLIED) {
                phase = Phase.SUCCESS; message = "Stock updated to " + command.quantity + ".";
            } else {
                preview = null; phase = Phase.ERROR;
                message = result == InventoryDatabaseHelper.AdjustmentResult.STALE
                        ? "Stock changed since your preview. Preview again before confirming."
                        : "This item was deleted. Return to inventory.";
            }
        }, error -> {
            preview = null; phase = Phase.ERROR;
            message = "Could not save the adjustment. Preview current stock before trying again.";
        });
    }

    public String adjustmentBackLabel() {
        return adjustmentReturnScreen == Screen.RESTOCK ? "Back to shortlist" : "Back to inventory";
    }

    public void cancel() {
        if (busy) return;
        preview = null; selected = null; deltaText = ""; reasonText = "";
        phase = Phase.EDITING; navigate(adjustmentReturnScreen);
    }

    public void loadSmsItem(String number) {
        pendingSmsNumber = number;
        run(repository::getLowStockItems, result -> {
            smsItem = result.isEmpty() ? null : result.get(0);
            message = result.isEmpty() ? getApplication().getString(R.string.no_low_stock_items) : "";
        }, this::failed);
    }

    @Override protected void onCleared() {
        disposed = true;
        worker.execute(repository::close);
        worker.shutdown();
    }
}
