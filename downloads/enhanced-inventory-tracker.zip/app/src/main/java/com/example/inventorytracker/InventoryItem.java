package com.example.inventorytracker;

/** Immutable inventory record returned by the SQLite data layer. */
public final class InventoryItem {

    private final long id;
    private final String name;
    private final String sku;
    private final int quantity;
    private final int lowStockThreshold;

    public InventoryItem(long id, String name, String sku, int quantity, int lowStockThreshold) {
        this.id = id;
        this.name = name;
        this.sku = sku;
        this.quantity = quantity;
        this.lowStockThreshold = lowStockThreshold;
    }

    public long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getSku() {
        return sku;
    }

    public int getQuantity() {
        return quantity;
    }

    public int getLowStockThreshold() {
        return lowStockThreshold;
    }

    public boolean isLowStock() {
        return quantity <= lowStockThreshold;
    }
}
