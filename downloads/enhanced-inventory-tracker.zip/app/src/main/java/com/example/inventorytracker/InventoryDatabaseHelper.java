package com.example.inventorytracker;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteConstraintException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.List;

/**
 * Owns account, inventory and transactional movement storage.
 * CS-499 Module Five — markmdev, October 4, 2026. Schema version 2.
 */
public final class InventoryDatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "inventory_tracker.db";
    private static final int DATABASE_VERSION = 2;

    private static final String TABLE_USERS = "users";
    private static final String TABLE_INVENTORY = "inventory";

    public InventoryDatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onConfigure(SQLiteDatabase database) {
        database.setForeignKeyConstraintsEnabled(true);
    }

    @Override
    public void onCreate(SQLiteDatabase database) {
        database.execSQL(
                "CREATE TABLE " + TABLE_USERS + " (" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        "username TEXT NOT NULL UNIQUE COLLATE NOCASE, " +
                        "password_hash TEXT NOT NULL, " +
                        "password_salt TEXT NOT NULL)"
        );
        database.execSQL(
                "CREATE TABLE " + TABLE_INVENTORY + " (" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        "name TEXT NOT NULL, " +
                        "sku TEXT NOT NULL UNIQUE COLLATE NOCASE, " +
                        "quantity INTEGER NOT NULL CHECK(quantity >= 0), " +
                        "low_stock_threshold INTEGER NOT NULL CHECK(low_stock_threshold >= 0))"
        );
        createMovementSchema(database);
    }

    @Override
    public void onUpgrade(SQLiteDatabase database, int oldVersion, int newVersion) {
        if (oldVersion < 2) createMovementSchema(database);
    }

    private void createMovementSchema(SQLiteDatabase database) {
        // Snapshots keep deleted items meaningful; migration leaves existing stock and accounts intact.
        database.execSQL("CREATE TABLE stock_movements (" +
                "id INTEGER PRIMARY KEY, " +
                "item_id INTEGER REFERENCES inventory(id) ON DELETE SET NULL, " +
                "sku TEXT NOT NULL, name TEXT NOT NULL, " +
                "old_quantity INTEGER NOT NULL CHECK(typeof(old_quantity) = 'integer' AND old_quantity BETWEEN 0 AND 2147483647), " +
                "delta INTEGER NOT NULL CHECK(typeof(delta) = 'integer' AND delta BETWEEN -2147483647 AND 2147483647 AND delta <> 0), " +
                "new_quantity INTEGER NOT NULL CHECK(typeof(new_quantity) = 'integer' AND new_quantity BETWEEN 0 AND 2147483647), " +
                "reason TEXT NOT NULL CHECK(length(trim(reason, char(9,10,11,12,13,32))) > 0), " +
                "created_at INTEGER NOT NULL CHECK(typeof(created_at) = 'integer'), " +
                "CHECK(old_quantity + delta = new_quantity))");
        database.execSQL("CREATE INDEX movement_item_time ON stock_movements(item_id, created_at, id)");
    }

    public boolean createUser(String username, String password) {
        String salt = PasswordHasher.newSalt();
        ContentValues values = new ContentValues();
        values.put("username", username);
        values.put("password_hash", PasswordHasher.hash(password, salt));
        values.put("password_salt", salt);
        try {
            return getWritableDatabase().insertOrThrow(TABLE_USERS, null, values) != -1;
        } catch (SQLiteConstraintException exception) {
            return false;
        }
    }

    public boolean authenticate(String username, String password) {
        try (Cursor cursor = getReadableDatabase().query(
                TABLE_USERS,
                new String[]{"password_hash", "password_salt"},
                "username = ?",
                new String[]{username},
                null,
                null,
                null,
                "1"
        )) {
            if (!cursor.moveToFirst()) {
                return false;
            }
            String expectedHash = cursor.getString(cursor.getColumnIndexOrThrow("password_hash"));
            String salt = cursor.getString(cursor.getColumnIndexOrThrow("password_salt"));
            String actualHash = PasswordHasher.hash(password, salt);
            return MessageDigest.isEqual(
                    expectedHash.getBytes(StandardCharsets.UTF_8),
                    actualHash.getBytes(StandardCharsets.UTF_8)
            );
        }
    }

    public boolean addItem(String name, String sku, int quantity, int threshold) {
        ContentValues values = new ContentValues();
        values.put("name", name);
        values.put("sku", sku);
        values.put("quantity", quantity);
        values.put("low_stock_threshold", threshold);
        try {
            return getWritableDatabase().insertOrThrow(TABLE_INVENTORY, null, values) != -1;
        } catch (SQLiteConstraintException exception) {
            return false;
        }
    }

    public enum AdjustmentResult { APPLIED, STALE, MISSING }

    public InventoryItem getItem(long id) {
        List<InventoryItem> items = queryItems("id = ?", new String[]{String.valueOf(id)}, null);
        return items.isEmpty() ? null : items.get(0);
    }

    public AdjustmentResult applyAdjustment(StockAdjustment preview) {
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            InventoryItem current = getItem(preview.item.getId());
            if (current == null) return AdjustmentResult.MISSING;
            if (current.getQuantity() != preview.item.getQuantity()) return AdjustmentResult.STALE;
            StockAdjustment checked = new StockAdjustment(current, preview.delta, preview.reason);
            ContentValues values = new ContentValues();
            values.put("quantity", checked.quantity);
            int updated = db.update(TABLE_INVENTORY, values, "id = ? AND quantity = ?",
                    new String[]{String.valueOf(current.getId()), String.valueOf(current.getQuantity())});
            if (updated != 1) throw new IllegalStateException("Adjustment did not update exactly one item.");
            ContentValues movement = new ContentValues();
            movement.put("item_id", current.getId());
            movement.put("sku", current.getSku());
            movement.put("name", current.getName());
            movement.put("old_quantity", current.getQuantity());
            movement.put("delta", checked.delta);
            movement.put("new_quantity", checked.quantity);
            movement.put("reason", checked.reason);
            movement.put("created_at", System.currentTimeMillis());
            // Any failed history insert rolls back the quantity update as part of this transaction.
            db.insertOrThrow("stock_movements", null, movement);
            db.setTransactionSuccessful();
            return AdjustmentResult.APPLIED;
        } finally {
            db.endTransaction();
        }
    }

    public List<StockMovement> getItemHistory(long itemId) {
        List<StockMovement> movements = new ArrayList<>();
        try (Cursor cursor = getReadableDatabase().query("stock_movements",
                new String[]{"id", "sku", "name", "old_quantity", "delta", "new_quantity", "reason", "created_at"},
                "item_id = ?", new String[]{String.valueOf(itemId)}, null, null, "created_at DESC, id DESC")) {
            while (cursor.moveToNext()) {
                movements.add(new StockMovement(cursor.getLong(0), cursor.getString(1), cursor.getString(2),
                        cursor.getInt(3), cursor.getInt(4), cursor.getInt(5), cursor.getString(6), cursor.getLong(7)));
            }
        }
        return movements;
    }

    public void deleteItem(long itemId) {
        getWritableDatabase().delete(
                TABLE_INVENTORY,
                "id = ?",
                new String[]{String.valueOf(itemId)}
        );
    }

    public List<InventoryItem> getAllItems() {
        return queryItems(null, null, "name COLLATE NOCASE ASC");
    }

    public List<InventoryItem> getLowStockItems() {
        return queryItems("quantity <= low_stock_threshold", null, "quantity ASC");
    }

    private List<InventoryItem> queryItems(
            String selection,
            String[] selectionArguments,
            String orderBy
    ) {
        List<InventoryItem> items = new ArrayList<>();
        try (Cursor cursor = getReadableDatabase().query(
                TABLE_INVENTORY,
                new String[]{"id", "name", "sku", "quantity", "low_stock_threshold"},
                selection,
                selectionArguments,
                null,
                null,
                orderBy
        )) {
            while (cursor.moveToNext()) {
                items.add(new InventoryItem(
                        cursor.getLong(cursor.getColumnIndexOrThrow("id")),
                        cursor.getString(cursor.getColumnIndexOrThrow("name")),
                        cursor.getString(cursor.getColumnIndexOrThrow("sku")),
                        cursor.getInt(cursor.getColumnIndexOrThrow("quantity")),
                        cursor.getInt(cursor.getColumnIndexOrThrow("low_stock_threshold"))
                ));
            }
        }
        return items;
    }
}
