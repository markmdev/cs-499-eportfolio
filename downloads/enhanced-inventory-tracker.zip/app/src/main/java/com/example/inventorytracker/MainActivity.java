package com.example.inventorytracker;

import android.Manifest;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.text.InputType;
import android.view.ViewGroup;
import android.widget.ScrollView;
import androidx.lifecycle.ViewModelProvider;
import android.telephony.SmsManager;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.util.List;

/**
 * Coordinates the login, inventory, item-entry, and notification screens.
 * CS-499 Module Five — markmdev, October 4, 2026. Enhancement version 3.
 */
public class MainActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_REQUEST = 1001;

    private InventoryViewModel model;
    private Toast activeToast;
    private InventoryViewModel.Screen renderedScreen;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        model = new ViewModelProvider(this).get(InventoryViewModel.class);
        model.changes.observe(this, ignored -> render());
        getOnBackPressedDispatcher().addCallback(this, new androidx.activity.OnBackPressedCallback(true) {
            @Override public void handleOnBackPressed() { navigateBack(); }
        });
    }

    private void render() {
        if (activeToast != null) activeToast.cancel();
        boolean newScreen = renderedScreen != model.screen;
        switch (model.screen) {
            case LOGIN:
                if (newScreen) {
                    setContentView(R.layout.activity_main);
                    findViewById(R.id.signInButton).setOnClickListener(v -> signIn());
                }
                break;
            case ACCOUNT:
                if (newScreen) {
                    setContentView(R.layout.activity_create_account);
                    findViewById(R.id.createAccountButton).setOnClickListener(v -> createAccount());
                }
                break;
            case INVENTORY:
                setContentView(R.layout.activity_inventory);
                renderInventory();
                break;
            case ADD:
                if (newScreen) {
                    setContentView(R.layout.activity_add_item);
                    findViewById(R.id.saveItemButton).setOnClickListener(v -> saveItem());
                }
                break;
            case NOTIFICATIONS:
                if (newScreen) setContentView(R.layout.activity_notifications);
                updateSmsPermissionStatus();
                if (model.smsItem != null) sendLowStockAlert();
                break;
            case RESTOCK: renderRestock(); break;
            case HISTORY: renderHistory(); break;
            case ADJUST: renderAdjustment(); break;
        }
        renderedScreen = model.screen;
        if (model.screen != InventoryViewModel.Screen.ADJUST && !model.message.isEmpty()) {
            toast(model.message);
        }
        setEnabled(findViewById(android.R.id.content), !model.busy);
    }

    private void setEnabled(View view, boolean enabled) {
        if (view instanceof Button || view instanceof EditText) view.setEnabled(enabled);
        if (view instanceof ViewGroup) {
            ViewGroup group = (ViewGroup) view;
            for (int i = 0; i < group.getChildCount(); i++) setEnabled(group.getChildAt(i), enabled);
        }
    }

    public void showLogin(View view) { model.navigate(InventoryViewModel.Screen.LOGIN); }
    public void showCreateAccount(View view) { model.navigate(InventoryViewModel.Screen.ACCOUNT); }
    public void showInventory(View view) { model.navigate(InventoryViewModel.Screen.INVENTORY); }
    public void showAddItem(View view) { model.navigate(InventoryViewModel.Screen.ADD); }
    public void showNotifications(View view) { model.navigate(InventoryViewModel.Screen.NOTIFICATIONS); }

    private void navigateBack() {
        if (model.busy) return;
        if (model.screen == InventoryViewModel.Screen.ADJUST) model.cancel();
        else if (model.screen == InventoryViewModel.Screen.ADD || model.screen == InventoryViewModel.Screen.NOTIFICATIONS || model.screen == InventoryViewModel.Screen.RESTOCK || model.screen == InventoryViewModel.Screen.HISTORY) showInventory(null);
        else showLogin(null);
    }

    private void signIn() {
        String username = textOf(R.id.usernameInput);
        String password = textOf(R.id.passwordInput);

        if (username.isEmpty() || password.isEmpty()) {
            toast(R.string.enter_credentials);
            return;
        }
        model.signIn(username, password, false);
    }

    private void createAccount() {
        String username = textOf(R.id.createUsernameInput);
        String password = textOf(R.id.createPasswordInput);
        String confirmation = textOf(R.id.confirmPasswordInput);

        if (username.isEmpty() || password.isEmpty()) {
            toast(R.string.enter_credentials);
            return;
        }
        if (!password.equals(confirmation)) {
            toast(R.string.passwords_do_not_match);
            return;
        }
        model.signIn(username, password, true);
    }

    private void saveItem() {
        String name = textOf(R.id.itemNameInput);
        String sku = textOf(R.id.skuInput);
        Integer quantity = integerOf(R.id.quantityInput);
        Integer threshold = integerOf(R.id.thresholdInput);

        if (name.isEmpty() || sku.isEmpty() || quantity == null || threshold == null) {
            toast(R.string.complete_item_fields);
            return;
        }
        model.add(name, sku, quantity, threshold);
    }

    private void renderInventory() {
        findViewById(R.id.restockButton).setOnClickListener(v -> model.navigate(InventoryViewModel.Screen.RESTOCK));
        List<InventoryItem> items = model.items;
        TextView subtitle = findViewById(R.id.inventorySubtitle);
        subtitle.setText(getResources().getQuantityString(
                R.plurals.inventory_count,
                items.size(),
                items.size(),
                countLowStock(items)
        ));

        TableLayout table = findViewById(R.id.inventoryTable);
        TextView emptyState = findViewById(R.id.emptyInventoryMessage);
        emptyState.setVisibility(items.isEmpty() ? View.VISIBLE : View.GONE);

        for (InventoryItem item : items) {
            table.addView(createInventoryRow(item));
        }
    }

    private TableRow createInventoryRow(InventoryItem item) {
        TableRow row = new TableRow(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, dp(8), 0, dp(8));

        LinearLayout nameCell = new LinearLayout(this);
        nameCell.setOrientation(LinearLayout.VERTICAL);
        TextView name = bodyText(item.getName());
        name.setTextColor(Color.rgb(23, 32, 51));
        TextView sku = bodyText(item.getSku());
        sku.setTextSize(12);
        sku.setTextColor(Color.rgb(95, 104, 120));
        nameCell.addView(name);
        nameCell.addView(sku);
        Button history = compactButton("History", 84);
        history.setContentDescription("History for " + item.getName());
        history.setOnClickListener(v -> model.showHistory(item));
        nameCell.addView(history);
        row.addView(nameCell, new TableRow.LayoutParams(dp(108), TableRow.LayoutParams.WRAP_CONTENT));

        LinearLayout quantityCell = new LinearLayout(this);
        quantityCell.setGravity(Gravity.CENTER);
        TextView quantity = bodyText(String.valueOf(item.getQuantity()));
        quantity.setGravity(Gravity.CENTER);
        Button adjust = compactButton("Adjust", 64);
        adjust.setContentDescription("Adjust " + item.getName());
        adjust.setOnClickListener(v -> model.select(item));
        quantityCell.setOrientation(LinearLayout.VERTICAL);
        quantityCell.addView(quantity);
        quantityCell.addView(adjust);
        row.addView(quantityCell, new TableRow.LayoutParams(dp(96), TableRow.LayoutParams.WRAP_CONTENT));

        TextView status = bodyText(item.isLowStock()
                ? getString(R.string.status_low)
                : getString(R.string.status_ok));
        status.setGravity(Gravity.CENTER);
        status.setTextColor(item.isLowStock()
                ? Color.rgb(163, 74, 0)
                : Color.rgb(25, 113, 60));
        row.addView(status, new TableRow.LayoutParams(dp(48), TableRow.LayoutParams.WRAP_CONTENT));

        Button delete = compactButton(getString(R.string.delete), 60);
        delete.setOnClickListener(ignored -> {
            model.delete(item.getId());
        });
        row.addView(delete, new TableRow.LayoutParams(dp(60), TableRow.LayoutParams.WRAP_CONTENT));
        return row;
    }

    private void renderRestock() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(24), dp(24), dp(24), dp(24));
        scroll.addView(content); setContentView(scroll);
        TextView title = bodyText("Restock shortlist"); title.setTextSize(28); content.addView(title);
        content.addView(bodyText("Stockouts first, then lowest quantity relative to the low-stock threshold. Ties use SKU, then item ID."));
        content.addView(bodyText("Number of items"));
        EditText limit = new EditText(this);
        limit.setId(R.id.restockLimit); limit.setInputType(InputType.TYPE_CLASS_NUMBER);
        limit.setText(model.restockLimitText); content.addView(limit);
        watch(limit, text -> model.restockLimitText = text);
        action(content, "Update shortlist", v -> model.loadRestock());
        if (model.busy) content.addView(bodyText("Loading shortlist…"));
        if (!model.message.isEmpty()) content.addView(bodyText(model.message));
        int rank = 1;
        for (InventoryItem item : model.restockItems) {
            content.addView(bodyText(rank++ + ". " + item.getName() + " · " + item.getSku()));
            content.addView(bodyText("Quantity: " + item.getQuantity() + " · Threshold: " + item.getLowStockThreshold()));
            Button adjust = new Button(this);
            adjust.setText("Adjust " + item.getName()); adjust.setAllCaps(false);
            adjust.setOnClickListener(v -> model.select(item)); content.addView(adjust);
        }
        action(content, "Back to inventory", v -> model.navigate(InventoryViewModel.Screen.INVENTORY));
    }

    private void renderHistory() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(24), dp(24), dp(24), dp(24));
        scroll.addView(content); setContentView(scroll);
        TextView title = bodyText("Stock history"); title.setTextSize(28); content.addView(title);
        content.addView(bodyText(model.selected.getName() + " · " + model.selected.getSku()));
        if (model.busy) content.addView(bodyText("Loading history…"));
        else if (!model.message.isEmpty()) {
            content.addView(bodyText(model.message));
            action(content, "Retry", v -> model.showHistory(model.selected));
        } else if (model.movements.isEmpty()) content.addView(bodyText("No recorded adjustments for this item."));
        java.time.format.DateTimeFormatter timestamp = java.time.format.DateTimeFormatter
                .ofPattern("yyyy-MM-dd HH:mm:ss.SSS 'UTC'", java.util.Locale.US).withZone(java.time.ZoneOffset.UTC);
        for (StockMovement movement : model.movements) {
            TextView date = bodyText(timestamp.format(java.time.Instant.ofEpochMilli(movement.createdAt)));
            date.setPadding(0, dp(20), 0, 0); content.addView(date);
            content.addView(bodyText(movement.name + " · " + movement.sku));
            content.addView(bodyText(movement.oldQuantity + " → " + movement.newQuantity +
                    " (" + (movement.delta > 0 ? "+" : "") + movement.delta + ")"));
            content.addView(bodyText("Reason: " + movement.reason));
        }
        action(content, "Back to inventory", v -> model.navigate(InventoryViewModel.Screen.INVENTORY));
    }

    private void renderAdjustment() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(24), dp(24), dp(24), dp(24));
        scroll.addView(content);
        setContentView(scroll);
        TextView title = bodyText("Adjust stock"); title.setTextSize(28); content.addView(title);
        content.addView(bodyText(model.selected.getName() + " · " + model.selected.getSku()));
        boolean showPreview = model.preview != null;
        if (showPreview) {
            StockAdjustment p = model.preview;
            content.addView(bodyText((model.phase == InventoryViewModel.Phase.SUCCESS ? "Previous quantity: " : "Current quantity: ") + p.item.getQuantity()));
            content.addView(bodyText("Change: " + (p.delta > 0 ? "+" : "") + p.delta));
            TextView result = bodyText("New quantity: " + p.quantity); result.setTextSize(24); content.addView(result);
            content.addView(bodyText("Reason: " + p.reason));
            if (model.phase == InventoryViewModel.Phase.PREVIEW) {
                action(content, "Confirm adjustment", v -> model.confirm());
                action(content, "Edit", v -> model.edit());
            }
        } else {
            content.addView(bodyText("Enter a signed change and a reason. Review the result before saving."));
            content.addView(bodyText("Quantity change"));
            EditText delta = new EditText(this);
            delta.setId(R.id.adjustmentDelta);
            delta.setHint("For example, +5 or -2");
            delta.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_SIGNED);
            delta.setText(model.deltaText); content.addView(delta);
            content.addView(bodyText("Reason"));
            EditText reason = new EditText(this);
            reason.setId(R.id.adjustmentReason);
            reason.setHint("For example, shipment received"); reason.setText(model.reasonText); content.addView(reason);
            watch(delta, text -> model.deltaText = text);
            watch(reason, text -> model.reasonText = text);
            action(content, "Preview adjustment", v -> model.preview());
        }
        if (model.busy) content.addView(bodyText(model.phase == InventoryViewModel.Phase.SAVING ? "Saving adjustment…" : "Loading current stock…"));
        if (!model.message.isEmpty()) {
            TextView message = bodyText(model.message); message.setContentDescription(model.message);
            message.setTextColor(model.phase == InventoryViewModel.Phase.SUCCESS ? Color.rgb(25,113,60) : Color.rgb(160,35,35));
            content.addView(message);
        }
        if (!model.busy) action(content, model.phase == InventoryViewModel.Phase.SUCCESS ? model.adjustmentBackLabel() : "Cancel", v -> model.cancel());
    }

    private void action(LinearLayout layout, String title, View.OnClickListener listener) {
        Button button = new Button(this); button.setText(title); button.setAllCaps(false);
        button.setOnClickListener(listener); layout.addView(button);
    }

    private void watch(EditText input, java.util.function.Consumer<String> changed) {
        input.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            public void onTextChanged(CharSequence s, int start, int before, int count) { changed.accept(s.toString()); }
            public void afterTextChanged(Editable value) { }
        });
    }

    public void requestSmsPermission(View view) {
        String phoneNumber = textOf(R.id.phoneNumberInput);
        if (phoneNumber.isEmpty()) {
            toast(R.string.enter_phone_number);
            return;
        }
        model.pendingSmsNumber = phoneNumber;

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {
            model.loadSmsItem(model.pendingSmsNumber);
            return;
        }

        ActivityCompat.requestPermissions(
                this,
                new String[]{Manifest.permission.SEND_SMS},
                SMS_PERMISSION_REQUEST
        );
    }

    @Override
    public void onRequestPermissionsResult(
            int requestCode,
            @NonNull String[] permissions,
            @NonNull int[] grantResults
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode != SMS_PERMISSION_REQUEST) {
            return;
        }

        updateSmsPermissionStatus();
        if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            model.loadSmsItem(model.pendingSmsNumber);
        } else {
            toast(R.string.sms_denied_inventory_works);
        }
    }

    @SuppressWarnings("deprecation")
    private void sendLowStockAlert() {
        InventoryItem item = model.smsItem;
        model.smsItem = null;
        String message = getString(
                R.string.low_stock_message,
                item.getName(),
                item.getQuantity(),
                item.getLowStockThreshold()
        );
        try {
            SmsManager.getDefault().sendTextMessage(model.pendingSmsNumber, null, message, null, null);
            toast(R.string.sms_sent);
        } catch (RuntimeException exception) {
            toast(R.string.sms_unavailable);
        }
    }

    private void updateSmsPermissionStatus() {
        TextView status = findViewById(R.id.smsPermissionStatus);
        if (status == null) {
            return;
        }
        boolean granted = ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED;
        status.setText(granted ? R.string.sms_permission_granted : R.string.sms_permission_not_granted);
        status.setTextColor(granted ? Color.rgb(25, 113, 60) : Color.rgb(95, 104, 120));
    }

    private int countLowStock(List<InventoryItem> items) {
        int count = 0;
        for (InventoryItem item : items) {
            if (item.isLowStock()) {
                count++;
            }
        }
        return count;
    }

    private String textOf(int viewId) {
        EditText input = findViewById(viewId);
        return input.getText().toString().trim();
    }

    private Integer integerOf(int viewId) {
        try {
            int value = Integer.parseInt(textOf(viewId));
            return value < 0 ? null : value;
        } catch (NumberFormatException exception) {
            return null;
        }
    }

    private TextView bodyText(String value) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(14);
        view.setPadding(dp(4), dp(4), dp(4), dp(4));
        return view;
    }

    private Button compactButton(String label, int widthDp) {
        Button button = new Button(this);
        button.setText(label);
        button.setTextSize(11);
        button.setAllCaps(false);
        button.setWidth(dp(widthDp));
        button.setMinWidth(0);
        button.setMinimumWidth(0);
        button.setMinHeight(dp(40));
        button.setPadding(0, 0, 0, 0);
        return button;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private void toast(int messageId) { toast(getString(messageId)); }

    private void toast(String message) {
        if (activeToast != null) activeToast.cancel();
        activeToast = Toast.makeText(this, message, Toast.LENGTH_SHORT);
        activeToast.show();
    }

    @Override protected void onDestroy() {
        if (activeToast != null) activeToast.cancel();
        super.onDestroy();
    }
}
