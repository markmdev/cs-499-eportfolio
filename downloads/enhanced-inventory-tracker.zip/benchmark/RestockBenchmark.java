import com.example.inventorytracker.*;
import java.util.*;

public class RestockBenchmark {
    private static volatile long sink;
    static List<InventoryItem> inventory(int n) {
        Random r=new Random(499+n); List<InventoryItem> items=new ArrayList<>();
        for(int i=0;i<n;i++)items.add(new InventoryItem(i,"Item "+i,"SKU-"+i,r.nextInt(101),1+r.nextInt(100)));
        return items;
    }
    static long time(List<InventoryItem> items,int k,boolean heap){
        long start=System.nanoTime();List<InventoryItem> answer=heap?RestockSelector.select(items,k):RestockSelector.fullSort(items,k);
        long elapsed=System.nanoTime()-start;long sum=0;for(InventoryItem i:answer)sum+=i.getId();sink=sum;return elapsed;
    }
    public static void main(String[] args){
        System.out.println("n,k,eligible,heap_median_ms,full_sort_median_ms,identical");
        for(int n:new int[]{100,10000,100000})for(int k:new int[]{5,n/2,n}){
            List<InventoryItem> items=inventory(n);int eligible=0;for(InventoryItem i:items)if(i.isLowStock())eligible++;
            List<InventoryItem> a=RestockSelector.select(items,k),b=RestockSelector.fullSort(items,k);
            boolean same=a.size()==b.size();for(int i=0;same&&i<a.size();i++)same=a.get(i).getId()==b.get(i).getId();
            if(!same)throw new AssertionError("Selection mismatch");
            for(int w=0;w<10;w++){time(items,k,true);time(items,k,false);}
            long[] h=new long[21],f=new long[21];
            for(int run=0;run<21;run++){if(run%2==0){h[run]=time(items,k,true);f[run]=time(items,k,false);}else{f[run]=time(items,k,false);h[run]=time(items,k,true);}}
            Arrays.sort(h);Arrays.sort(f);
            System.out.printf(Locale.ROOT,"%d,%d,%d,%.6f,%.6f,%s%n",n,k,eligible,h[10]/1e6,f[10]/1e6,same);
        }
    }
}
